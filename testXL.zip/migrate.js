const Sequelize = require('sequelize');
const XLSX = require('xlsx');
const moment = require('moment');
const fs = require('fs');
const path = require('path');


const sequelize = new Sequelize('xlsx_db', 'xlsx', 'xlsx', {
    host: 'localhost',
    dialect: 'mysql'
  });
  
  const Title = sequelize.define('Title', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    title: {
      type: Sequelize.STRING,
      allowNull: false
    }
  });
  
  const Subtitle = sequelize.define('Subtitle', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    subtitle: {
      type: Sequelize.STRING,
      allowNull: false
    }
  });
  
  const Description = sequelize.define('Description', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    description: {
      type: Sequelize.STRING,
      allowNull: false
    }
  });
  
  const Summary = sequelize.define('Summary', {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    title: {
      type: Sequelize.STRING,
      allowNull: false
    },
    total: {
        type: Sequelize.FLOAT,
        allowNull: false
      }
  });
  
  const Content = sequelize.define('Content', {
    item_no: {
      type: Sequelize.FLOAT,
      allowNull: false
    },
    description: {
      type: Sequelize.STRING,
      allowNull: false,
      
    },
    unit: {
      type: Sequelize.STRING,
      allowNull: false
    },
    quantity: {
      type: Sequelize.INTEGER,
      allowNull: false
    },
    rate: {
      type: Sequelize.FLOAT,
      allowNull: false
    },
    amount: {
      type: Sequelize.FLOAT,
      allowNull: false
    }
  });
  
  Title.hasMany(Subtitle);
  Subtitle.belongsTo(Title);
  Subtitle.hasMany(Description);
  Description.belongsTo(Subtitle);
  Subtitle.hasMany(Summary);
  Summary.belongsTo(Subtitle);
  Description.hasMany(Content);
  Content.belongsTo(Description);
  
  (async () => {
    try {
      await sequelize.authenticate();
      console.log('Connection has been established successfully.');
      await sequelize.sync({ force: true });
      console.log('Tables synchronized successfully.');
    } catch (error) {
      console.error('Unable to connect to the database:', error);
    }
  })();