1. create user and database manually
2. change the trylat.js and migrate.js with right credention.. username password and database name
3. install packages with npm install
4. run migration script
5. run trylat script
6. still have some bugs.. to do.. change the max allowed character for description table ... 